/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author willy
 */
@Entity
@Table(name = "repuestoManteni")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "RepuestoManteni.findAll", query = "SELECT r FROM RepuestoManteni r"),
    @NamedQuery(name = "RepuestoManteni.findByIdRepuestoManteni", query = "SELECT r FROM RepuestoManteni r WHERE r.idRepuestoManteni = :idRepuestoManteni"),
    @NamedQuery(name = "RepuestoManteni.findByIdManteni", query = "SELECT r FROM RepuestoManteni r WHERE r.idMantenimiento.idMantenimiento = :idMantenimiento"),
    @NamedQuery(name = "RepuestoManteni.findByEstado", query = "SELECT r FROM RepuestoManteni r WHERE r.estado = :estado"),
    @NamedQuery(name = "RepuestoManteni.findByFechaRegistro", query = "SELECT r FROM RepuestoManteni r WHERE r.fechaRegistro = :fechaRegistro"),
    @NamedQuery(name = "RepuestoManteni.findByFechaCambio", query = "SELECT r FROM RepuestoManteni r WHERE r.fechaCambio = :fechaCambio"),
    @NamedQuery(name = "RepuestoManteni.findByRegistrador", query = "SELECT r FROM RepuestoManteni r WHERE r.registrador = :registrador")})
public class RepuestoManteni implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idRepuestoManteni")
    private Long idRepuestoManteni;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "estado")
    private String estado;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaRegistro")
    @Temporal(TemporalType.DATE)
    private Date fechaRegistro;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaCambio")
    @Temporal(TemporalType.DATE)
    private Date fechaCambio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "registrador")
    private long registrador;
    @JoinColumn(name = "idMantenimiento", referencedColumnName = "idMantenimiento")
    @ManyToOne(optional = false)
    private Mantenimiento idMantenimiento;
    @JoinColumn(name = "idRepuesto", referencedColumnName = "idRepuesto")
    @ManyToOne(optional = false)
    private Repuesto idRepuesto;

    public RepuestoManteni() {
    }

    public RepuestoManteni(Long idRepuestoManteni) {
        this.idRepuestoManteni = idRepuestoManteni;
    }

    public RepuestoManteni(Long idRepuestoManteni, String estado, Date fechaRegistro, Date fechaCambio, long registrador) {
        this.idRepuestoManteni = idRepuestoManteni;
        this.estado = estado;
        this.fechaRegistro = fechaRegistro;
        this.fechaCambio = fechaCambio;
        this.registrador = registrador;
    }

    public Long getIdRepuestoManteni() {
        return idRepuestoManteni;
    }

    public void setIdRepuestoManteni(Long idRepuestoManteni) {
        this.idRepuestoManteni = idRepuestoManteni;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public Date getFechaCambio() {
        return fechaCambio;
    }

    public void setFechaCambio(Date fechaCambio) {
        this.fechaCambio = fechaCambio;
    }

    public long getRegistrador() {
        return registrador;
    }

    public void setRegistrador(long registrador) {
        this.registrador = registrador;
    }

    public Mantenimiento getIdMantenimiento() {
        return idMantenimiento;
    }

    public void setIdMantenimiento(Mantenimiento idMantenimiento) {
        this.idMantenimiento = idMantenimiento;
    }

    public Repuesto getIdRepuesto() {
        return idRepuesto;
    }

    public void setIdRepuesto(Repuesto idRepuesto) {
        this.idRepuesto = idRepuesto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idRepuestoManteni != null ? idRepuestoManteni.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof RepuestoManteni)) {
            return false;
        }
        RepuestoManteni other = (RepuestoManteni) object;
        if ((this.idRepuestoManteni == null && other.idRepuestoManteni != null) || (this.idRepuestoManteni != null && !this.idRepuestoManteni.equals(other.idRepuestoManteni))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.mavenproject4.entity.RepuestoManteni[ idRepuestoManteni=" + idRepuestoManteni + " ]";
    }
    
}
