/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.ejb;

import com.mycompany.pruebaFA.entity.RepuestoManteni;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author willy
 */
@Local
public interface RepuestoManteniFacadeLocal {

    void create(RepuestoManteni repuestoManteni);

    void edit(RepuestoManteni repuestoManteni);

    void remove(RepuestoManteni repuestoManteni);

    RepuestoManteni find(Object id);

    List<RepuestoManteni> findAll();

    List<RepuestoManteni> findRange(int[] range);

    int count();
    
    List<RepuestoManteni> findByIdManteni(Long idMantenimiento);
    
}
