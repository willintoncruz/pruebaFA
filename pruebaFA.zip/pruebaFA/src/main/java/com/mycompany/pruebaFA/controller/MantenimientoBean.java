/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.controller;


import com.mycompany.pruebaFA.ejb.MantenimientoFacadeLocal;
import com.mycompany.pruebaFA.ejb.PersonaFacadeLocal;
import com.mycompany.pruebaFA.ejb.RepuestoFacadeLocal;
import com.mycompany.pruebaFA.ejb.RepuestoManteniFacadeLocal;
import com.mycompany.pruebaFA.ejb.RolFacadeLocal;
import com.mycompany.pruebaFA.ejb.RolpersonaFacadeLocal;
import com.mycompany.pruebaFA.ejb.ServiMantenimientoFacadeLocal;
import com.mycompany.pruebaFA.ejb.ServicioFacadeLocal;
import com.mycompany.pruebaFA.ejb.VehiculoFacadeLocal;
import com.mycompany.pruebaFA.entity.Mantenimiento;
import com.mycompany.pruebaFA.entity.Persona;
import com.mycompany.pruebaFA.entity.Repuesto;
import com.mycompany.pruebaFA.entity.RepuestoManteni;
import com.mycompany.pruebaFA.entity.Rol;
import com.mycompany.pruebaFA.entity.Rolpersona;
import com.mycompany.pruebaFA.entity.ServiMantenimiento;
import com.mycompany.pruebaFA.entity.Servicio;
import com.mycompany.pruebaFA.entity.TipoDocumento;
import com.mycompany.pruebaFA.entity.Vehiculo;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.transaction.UserTransaction;
import javax.annotation.Resource;
import javax.transaction.Status;

/**
 *
 * @author willy
 */
@ManagedBean
@SessionScoped
@TransactionManagement(TransactionManagementType.BEAN)
public class MantenimientoBean {

    /**
     * @return the serviMantenimiento
     */
    public ServiMantenimiento getServiMantenimiento() {
        return serviMantenimiento;
    }

    /**
     * @param serviMantenimiento the serviMantenimiento to set
     */
    public void setServiMantenimiento(ServiMantenimiento serviMantenimiento) {
        this.serviMantenimiento = serviMantenimiento;
    }

    /**
     * @return the servicioAdd
     */
    public Servicio getServicioAdd() {
        return servicioAdd;
    }

    /**
     * @param servicioAdd the servicioAdd to set
     */
    public void setServicioAdd(Servicio servicioAdd) {
        this.servicioAdd = servicioAdd;
    }

    /**
     * @return the sergvicioManteList
     */
    public List<ServiMantenimiento> getSergvicioManteList() {
        return sergvicioManteList;
    }

    /**
     * @param sergvicioManteList the sergvicioManteList to set
     */
    public void setSergvicioManteList(List<ServiMantenimiento> sergvicioManteList) {
        this.sergvicioManteList = sergvicioManteList;
    }

    /**
     * @return the servicioListAdd
     */
    public List<Servicio> getServicioListAdd() {
        return servicioListAdd;
    }

    /**
     * @param servicioListAdd the servicioListAdd to set
     */
    public void setServicioListAdd(List<Servicio> servicioListAdd) {
        this.servicioListAdd = servicioListAdd;
    }

    /**
     * @return the showServicio
     */
    public boolean isShowServicio() {
        return showServicio;
    }

    /**
     * @param showServicio the showServicio to set
     */
    public void setShowServicio(boolean showServicio) {
        this.showServicio = showServicio;
    }

    /**
     * @return the repuestoManteList
     */
    public List<RepuestoManteni> getRepuestoManteList() {
        return repuestoManteList;
    }

    /**
     * @param repuestoManteList the repuestoManteList to set
     */
    public void setRepuestoManteList(List<RepuestoManteni> repuestoManteList) {
        this.repuestoManteList = repuestoManteList;
    }

    /**
     * @return the mantenimientoRep
     */
    public Mantenimiento getMantenimientoRep() {
        return mantenimientoRep;
    }

    /**
     * @param mantenimientoRep the mantenimientoRep to set
     */
    public void setMantenimientoRep(Mantenimiento mantenimientoRep) {
        this.mantenimientoRep = mantenimientoRep;
    }

    /**
     * @return the repuestoManteni
     */
    public RepuestoManteni getRepuestoManteni() {
        return repuestoManteni;
    }

    /**
     * @param repuestoManteni the repuestoManteni to set
     */
    public void setRepuestoManteni(RepuestoManteni repuestoManteni) {
        this.repuestoManteni = repuestoManteni;
    }

    /**
     * @return the repuestoAdd
     */
    public Repuesto getRepuestoAdd() {
        return repuestoAdd;
    }

    /**
     * @param repuestoAdd the repuestoAdd to set
     */
    public void setRepuestoAdd(Repuesto repuestoAdd) {
        this.repuestoAdd = repuestoAdd;
    }

    /**
     * @return the repuestoListAdd
     */
    public List<Repuesto> getRepuestoListAdd() {
        return repuestoListAdd;
    }

    /**
     * @param repuestoListAdd the repuestoListAdd to set
     */
    public void setRepuestoListAdd(List<Repuesto> repuestoListAdd) {
        this.repuestoListAdd = repuestoListAdd;
    }

    /**
     * @return the repuesto
     */
    public Repuesto getRepuesto() {
        return repuesto;
    }

    /**
     * @param repuesto the repuesto to set
     */
    public void setRepuesto(Repuesto repuesto) {
        this.repuesto = repuesto;
    }

    /**
     * @return the showRepuesto
     */
    public boolean isShowRepuesto() {
        return showRepuesto;
    }

    /**
     * @param showRepuesto the showRepuesto to set
     */
    public void setShowRepuesto(boolean showRepuesto) {
        this.showRepuesto = showRepuesto;
    }

    /**
     * @return the repuestoList
     */
    public List<Repuesto> getRepuestoList() {
        return repuestoList;
    }

    /**
     * @param repuestoList the repuestoList to set
     */
    public void setRepuestoList(List<Repuesto> repuestoList) {
        this.repuestoList = repuestoList;
    }

    /**
     * @return the mecanicoInicial
     */
    public Persona getMecanicoInicial() {
        return mecanicoInicial;
    }

    /**
     * @param mecanicoInicial the mecanicoInicial to set
     */
    public void setMecanicoInicial(Persona mecanicoInicial) {
        this.mecanicoInicial = mecanicoInicial;
    }

   
     @Resource
   private UserTransaction userTransaction;
    
     @EJB
    private PersonaFacadeLocal personaFacadeLocal;
     
     @EJB
    private RolFacadeLocal rolFacadeLocal;
     
      @EJB
    private MantenimientoFacadeLocal mantenimientoFacadeLocal;
      
      @EJB
    private VehiculoFacadeLocal vehiculoFacadeLocal;
     
     @EJB
    private RolpersonaFacadeLocal rolpersonaFacadeLocal;
     
    @EJB
    private RepuestoFacadeLocal repuestoFacadeLocal;
    
    @EJB
    private RepuestoManteniFacadeLocal repuestoManteniFacadeLocal;
    
    @EJB
    private ServicioFacadeLocal servicioFacadeLocal;
    
    @EJB
    private ServiMantenimientoFacadeLocal serviMantenimientoFacadeLocal;
     
    private List<Mantenimiento> mantenimientoList;
    private Persona persona;
    private TipoDocumento tipoDocumento;
    private Rolpersona rolpersona;
    private Rol rol;
    private String msj;
    private Vehiculo vehiculo;
    private Mantenimiento mantenimiento;
    private List<Persona> mecanicoList;
    private Persona mecanico;
    private Persona mecanicoBuscado;
    private Rol rolMecanico;
    private Persona mecanicoInicial;
    private List<Repuesto> repuestoList;
    private boolean showRepuesto=false;
    private Repuesto repuesto;
    private List<Repuesto> repuestoListAdd;
    private Repuesto repuestoAdd;
    private RepuestoManteni repuestoManteni;
    private List<RepuestoManteni> repuestoManteList;
    private Mantenimiento mantenimientoRep;
    private boolean showServicio=false;
    private List<Servicio> servicioListAdd;
    private List<ServiMantenimiento> sergvicioManteList;
    private Servicio servicioAdd;
    private ServiMantenimiento serviMantenimiento;
    
     /**
     * @return the rolMecanico
     */
    public Rol getRolMecanico() {
        return rolMecanico;
    }

    /**
     * @param rolMecanico the rolMecanico to set
     */
    public void setRolMecanico(Rol rolMecanico) {
        this.rolMecanico = rolMecanico;
    }

    
    
    /**
     * @return the mecanicoBuscado
     */
    public Persona getMecanicoBuscado() {
        return mecanicoBuscado;
    }

    /**
     * @param mecanicoBuscado the mecanicoBuscado to set
     */
    public void setMecanicoBuscado(Persona mecanicoBuscado) {
        this.mecanicoBuscado = mecanicoBuscado;
    }

    /**
     * @return the mecanico
     */
    public Persona getMecanico() {
        return mecanico;
    }

    /**
     * @param mecanico the mecanico to set
     */
    public void setMecanico(Persona mecanico) {
        this.mecanico = mecanico;
    }

    /**
     * @return the mecanicoList
     */
    public List<Persona> getMecanicoList() {
        return mecanicoList;
    }

    /**
     * @param mecanicoList the mecanicoList to set
     */
    public void setMecanicoList(List<Persona> mecanicoList) {
        this.mecanicoList = mecanicoList;
    }

    /**
     * @return the mantenimiento
     */
    public Mantenimiento getMantenimiento() {
        return mantenimiento;
    }

    /**
     * @param mantenimiento the mantenimiento to set
     */
    public void setMantenimiento(Mantenimiento mantenimiento) {
        this.mantenimiento = mantenimiento;
    }

    /**
     * @return the vehiculo
     */
    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    /**
     * @param vehiculo the vehiculo to set
     */
    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }
    
   
    /**
     * @return the tipoDocumento
     */
    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }

    /**
     * @param tipoDocumento the tipoDocumento to set
     */
    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }
    
   
    
    
    public List<Mantenimiento> getMantenimientoList() {
        this.mantenimientoList = mantenimientoFacadeLocal.findAll();
        
        this.rol = rolFacadeLocal.findByName("CLIENTE");
        this.rolMecanico = rolFacadeLocal.findByName("MECANICO");
        this.setRepuestoListAdd(repuestoFacadeLocal.findAll());
        this.cargarMecanicos();
        return mantenimientoList;
    }
 
    public void setMantenimientoList(List<Mantenimiento> mantenimientoList) {
        this.mantenimientoList = mantenimientoList;
    }
 
    public Persona getPersona() {
        return persona;
    }
 
    public void setPersona(Persona persona) {
        this.persona = persona;
    }
 
    @PostConstruct
    public void init() {
        this.persona = new Persona();
        this.tipoDocumento = new TipoDocumento();
        this.rolpersona = new Rolpersona();
        this.vehiculo = new Vehiculo();
        this.mantenimiento = new Mantenimiento();
        this.mantenimiento.setIdMecanico(new Persona());
        this.mecanico = new Persona();
        this.mecanicoInicial= new Persona();
        this.repuesto = new Repuesto();
        this.repuestoAdd = new Repuesto();
        this.repuestoManteni = new RepuestoManteni();
        this.servicioAdd = new Servicio();
        this.serviMantenimiento = new ServiMantenimiento();
        
    }
            
    public void limpiarDatos() {
        this.persona = new Persona();
        this.tipoDocumento = new TipoDocumento();
        this.vehiculo = new Vehiculo();
        this.mantenimiento = new Mantenimiento();
        this.mecanico = new Persona();
        this.repuesto = new Repuesto();
        this.repuestoAdd = new Repuesto();
        this.repuestoManteni = new RepuestoManteni();
        
    }
    
    public void cargarMecanicos() {
        System.out.println("esta cargarMecanicos:::::::::::");
        //this.setMecanicoList(personaFacadeLocal.findAllByIdRol(1));
        setMecanicoList(personaFacadeLocal.findByMecAsignado());
        
        System.out.println("getMecanicoList inicial "+this.getMecanicoList());
        
        if(getMecanicoList()!=null && getMecanicoList().size()<10){
            int faltante= 10 - getMecanicoList().size();
            getMecanicoList().addAll(personaFacadeLocal.findByMecNoAsignado(faltante));            
        }else if(getMecanicoList()==null || (getMecanicoList()!=null && getMecanicoList().size()==0) ){
            setMecanicoList(personaFacadeLocal.findByMecNoAsignado(10));
        }
        //System.out.println("getMecanicoList "+this.getMecanicoList());
    }
    
    public void cargarMecanicosEdit() {
        this.setMecanicoList(personaFacadeLocal.findAllByIdRol(1));
                
        System.out.println("getMecanicoList inicial "+this.getMecanicoList());  
    }
    
  
    public void guardar() throws Exception{
        try {
            
            userTransaction.begin();
            
            this.msj = "Registro creado correctamente";
            System.out.println("tipoDocumento:::::::" + this.tipoDocumento.getIdTipoDoc());
            //crea la persona cliente
            persona.setIdTipoDoc(this.tipoDocumento);
            persona.setFechaCambio(new Date());
            persona.setFechaRegistro(new Date());
            persona.setRegistrador(1);
            personaFacadeLocal.create(persona);
            
            //this.rol.setIdRol(77);
            //asigna el rol cliente
            rolpersona= new Rolpersona();
            rolpersona.setIdRol(this.rol);
            rolpersona.setEstado("A");
            rolpersona.setFechaCambio(new Date());
            rolpersona.setFechaRegistro(new Date());
            rolpersona.setRegistrador(1);
            rolpersona.setIdPersona(persona);
            
            rolpersonaFacadeLocal.create(rolpersona);
            
            //crea el vehiculo
            vehiculo.setFechaCambio(new Date());
            vehiculo.setFechaRegistro(new Date());
            vehiculo.setRegistrador(1);
            vehiculo.setIdPersona(persona);
            
            vehiculoFacadeLocal.create(vehiculo);
            
            //registra la solicitud de mantenimiento
            mantenimiento.setFechaCambio(new Date());
            mantenimiento.setFechaRegistro(new Date());
            mantenimiento.setRegistrador(1);
            mantenimiento.setIdVehiculo(vehiculo);
            if( mecanico.getIdPersona()!=null){
                mantenimiento.setIdMecanico(mecanico);
            }
            
            mantenimientoFacadeLocal.create(mantenimiento);
            
            //actualiza el estado del mecanico a asignado (ocupado)
            if( mantenimiento.getIdMecanico()!=null && mantenimiento.getIdMecanico().getIdPersona()!=null){
                rolpersona= rolpersonaFacadeLocal.findByIdRolIdPersona(mantenimiento.getIdMecanico().getIdPersona(), this.rolMecanico.getIdRol());            
                rolpersona.setEstado("A");
                rolpersona.setFechaCambio(new Date());            
                rolpersonaFacadeLocal.edit(rolpersona);
            }
            
            this.getMantenimientoList();
            userTransaction.commit();
            
            limpiarDatos();
        } catch (Exception e) {
            
            e.printStackTrace();
            System.out.println(":::::::::::::error en la transaccion:::::::::::");
            //this.msj = "Error: " + e.getMessage();
            this.msj = "Error: error en la transaccion";
            //userTransaction.rollback();
            if (userTransaction.getStatus() == Status.STATUS_ACTIVE)
                    userTransaction.rollback();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    
    public void cargarDatos(Mantenimiento reg) {
        try {
            this.cargarMecanicosEdit();
            this.mantenimiento.setIdMecanico(new Persona());
            this.persona.setIdPersona(reg.getIdVehiculo().getIdPersona().getIdPersona());
            this.persona.setNombre1(reg.getIdVehiculo().getIdPersona().getNombre1());
            this.persona.setNombre2(reg.getIdVehiculo().getIdPersona().getNombre2());
            this.persona.setApellido1(reg.getIdVehiculo().getIdPersona().getApellido1());
            this.persona.setApellido2(reg.getIdVehiculo().getIdPersona().getApellido2());
            this.persona.setIdTipoDoc(reg.getIdVehiculo().getIdPersona().getIdTipoDoc());
            this.persona.setEmail(reg.getIdVehiculo().getIdPersona().getEmail());
            this.persona.setDireccion(reg.getIdVehiculo().getIdPersona().getDireccion());
            this.persona.setTelefono(reg.getIdVehiculo().getIdPersona().getTelefono());
            this.persona.setNumeroDoc(reg.getIdVehiculo().getIdPersona().getNumeroDoc());
            this.setPersona(reg.getIdVehiculo().getIdPersona());
            
            this.tipoDocumento.setIdTipoDoc(this.persona.getIdTipoDoc().getIdTipoDoc());
            
            this.persona.setFechaCambio(reg.getFechaCambio());
            this.persona.setFechaRegistro(reg.getFechaRegistro());            
            this.persona.setRegistrador(reg.getRegistrador());
            
            this.vehiculo.setPlaca(reg.getIdVehiculo().getPlaca());
            this.vehiculo.setModelo(reg.getIdVehiculo().getModelo());
            this.vehiculo.setMarca(reg.getIdVehiculo().getMarca());
            this.vehiculo.setTelefono(reg.getIdVehiculo().getTelefono());
            this.setVehiculo(reg.getIdVehiculo());
            //this.mecanico= reg.getIdMecanico();
            this.mantenimiento=reg;
            //this.mantenimiento.setFechaRegistro(reg.getFechaRegistro());
            //this.mantenimiento.setIdVehiculo(vehiculo);
            
            this.mecanico= reg.getIdMecanico();
            this.mecanicoInicial= reg.getIdMecanico();
            System.out.println("cargarDatos mecanicoInicial.toString():::" + mecanicoInicial.toString());
            
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
    }
    
    public void cargarRepuestos(Mantenimiento reg) {
        this.setRepuestoList(repuestoFacadeLocal.findByIdMantenimiento(reg.getIdMantenimiento()));
           //this.showRepuesto=!this.showRepuesto;     
        System.out.println("cargarRepuestos getRepuestoList inicial "+this.getRepuestoList());  
    }
    
    public void cargarRepuestosAgregar(Mantenimiento reg) {
        this.mantenimientoRep = reg;
        this.setRepuestoListAdd(repuestoFacadeLocal.findAll());
        this.setRepuestoList(repuestoFacadeLocal.findByIdMantenimiento(reg.getIdMantenimiento()));
        
        this.repuestoManteList= repuestoManteniFacadeLocal.findByIdManteni(reg.getIdMantenimiento());
        
        this.showRepuesto=true;
        this.showServicio= false;
        System.out.println("cargarRepuestosAgregar getRepuestoList inicial "+this.getRepuestoList());  
    }
    
    public void cargarServiciosAgregar(Mantenimiento reg) {
        this.mantenimientoRep = reg;
        this.setServicioListAdd(servicioFacadeLocal.findAll());//lista todos los servicios
        //this.setRepuestoList(repuestoFacadeLocal.findByIdMantenimiento(reg.getIdMantenimiento()));
        
        this.sergvicioManteList= serviMantenimientoFacadeLocal.findByIdManteni(reg.getIdMantenimiento());
        
        this.showRepuesto=false;      
        this.showServicio= true;
        System.out.println("cargarServiciosAgregar getServicioListAdd inicial "+this.getServicioListAdd());  
    }
    
    
    
    public void actualizar() throws Exception{
        try {
            
            userTransaction.begin();
            
            this.msj = "Registro actualizado correctamente";
            persona.setFechaCambio(new Date());
            persona.setRegistrador(1);
            persona.setIdTipoDoc(this.tipoDocumento);
            personaFacadeLocal.edit(persona);
            
            vehiculo.setFechaCambio(new Date());
            vehiculo.setRegistrador(1);            
            vehiculoFacadeLocal.edit(vehiculo);            
                     
            System.out.println("mecanicoInicial.toString():::" + mecanicoInicial.toString());
            
            mantenimiento.setFechaCambio(new Date());
            mantenimiento.setRegistrador(1);
            mantenimiento.setIdVehiculo(vehiculo);  
            if( mecanico.getIdPersona()!=null){
                mantenimiento.setIdMecanico(mecanico);
                this.mecanicoBuscado= personaFacadeLocal.findByIdPersona(this.mecanico.getIdPersona());
                mantenimiento.setIdMecanico(this.mecanicoBuscado);
            }
           
            mantenimientoFacadeLocal.edit(mantenimiento);            
            
            //actualiza el estado del mecanico a asignado (ocupado)
            if( mantenimiento.getIdMecanico()!=null && mantenimiento.getIdMecanico().getIdPersona()!=null){
                rolpersona= rolpersonaFacadeLocal.findByIdRolIdPersona(mantenimiento.getIdMecanico().getIdPersona(), this.rolMecanico.getIdRol());            
                rolpersona.setEstado("A");
                rolpersona.setFechaCambio(new Date());            
                rolpersonaFacadeLocal.edit(rolpersona);
            }
            
            userTransaction.commit();
            limpiarDatos();
        } catch (Exception e) {
            
            e.printStackTrace();
            //this.msj = "Error: " + e.getMessage();
            this.msj = "Error: error en la transaccion";
            //userTransaction.rollback();
            if (userTransaction.getStatus() == Status.STATUS_ACTIVE)
                    userTransaction.rollback();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    public void eliminar(Mantenimiento reg) throws Exception{
        try {
            
            userTransaction.begin();
            this.msj = "Registro eliminado correctamente";
            mantenimientoFacadeLocal.remove(reg); 
            
            //actualiza el estado del mecanico a Libre)
            if( reg.getIdMecanico()!=null && reg.getIdMecanico().getIdPersona()!=null){
                rolpersona= rolpersonaFacadeLocal.findByIdRolIdPersona(reg.getIdMecanico().getIdPersona(), this.rolMecanico.getIdRol());            
                rolpersona.setEstado("L");
                rolpersona.setFechaCambio(new Date());            
                rolpersonaFacadeLocal.edit(rolpersona);
            }
            userTransaction.commit();
            limpiarDatos();
        } catch (Exception e) {
            
            e.printStackTrace();
            //this.msj = "Error: " + e.getMessage();
            this.msj = "Error: error en la transaccion";
            //userTransaction.rollback();
            if (userTransaction.getStatus() == Status.STATUS_ACTIVE)
                    userTransaction.rollback();
        }
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    public void guardarRepuestoMante() {
        try {
            this.msj = "Registro creado correctamente";
            System.out.println("tipoDocumento:::::::" + this.tipoDocumento.getIdTipoDoc());
            System.out.println("repuestoAdd:::" + repuestoAdd.getPrecio());
            //crea el repuesto mantenimiento
            repuestoManteni.setEstado("P");//Pendiente de aprobación
            repuestoManteni.setFechaCambio(new Date());
            repuestoManteni.setFechaRegistro(new Date());
            repuestoManteni.setRegistrador(1);
            repuestoManteni.setIdRepuesto(repuestoAdd);
            repuestoManteni.setIdMantenimiento(mantenimientoRep);
            
            repuestoManteniFacadeLocal.create(repuestoManteni);
                        
            //this.cargarRepuestos(mantenimientoRep);
            
            long idMantenimiento = repuestoManteni.getIdMantenimiento().getIdMantenimiento();
            this.repuestoManteList= repuestoManteniFacadeLocal.findByIdManteni(idMantenimiento);
            
            limpiarDatos();
        } catch (Exception e) {            
            e.printStackTrace();
            System.out.println(":::::::::::::error en la transaccion:::::::::::");
            this.msj = "Error: " + e.getMessage();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    public void cargarDatosRepuesto(Repuesto rep) {
        try {
            this.setRepuestoListAdd(repuestoFacadeLocal.findAll());
            this.repuestoAdd = rep;            
            //System.out.println("cargarDatos mecanicoInicial.toString():::" + mecanicoInicial.toString());
            System.out.println("rep.idRepuestoManteni:::." + rep.getIdRepuestoManteni());
            
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
    }
    
    public void actualizarRepuestoMante() {
        try {
            this.msj = "Registro creado correctamente";
            System.out.println("tipoDocumento:::::::" + this.tipoDocumento.getIdTipoDoc());
            //crea el repuesto mantenimiento
            repuestoManteni.setEstado("P");//Pendiente de aprobación
            repuestoManteni.setFechaCambio(new Date());
            repuestoManteni.setRegistrador(1);
            repuestoManteni.setIdRepuesto(repuestoAdd);
            repuestoManteni.setIdMantenimiento(mantenimientoRep);
            System.out.println("antes de actualizar repuestoAdd.getIdRepuestoManteni()" + repuestoAdd.getIdRepuestoManteni());
            repuestoManteni.setIdRepuestoManteni(repuestoAdd.getIdRepuestoManteni());
            
            repuestoManteniFacadeLocal.edit(repuestoManteni );
                        
            this.cargarRepuestos(mantenimientoRep);
          
            
            limpiarDatos();
        } catch (Exception e) {            
            e.printStackTrace();
            System.out.println(":::::::::::::error en la transaccion:::::::::::");
            this.msj = "Error: " + e.getMessage();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    
    public void eliminarRepMan(RepuestoManteni reg) throws Exception{
        try {           
           long idMantenimiento = reg.getIdMantenimiento().getIdMantenimiento();
            this.msj = "Registro eliminado correctamente";
            repuestoManteniFacadeLocal.remove(reg);
            limpiarDatos();
            this.repuestoManteList= repuestoManteniFacadeLocal.findByIdManteni(idMantenimiento);
        } catch (Exception e) {            
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();          
        }
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    public void guardarServicioMante() {
        try {
            this.msj = "Registro creado correctamente";           
            //crea el servicio mantenimiento
            serviMantenimiento.setEstado("P");//Pendiente de aprobación
            serviMantenimiento.setFechaCambio(new Date());
            serviMantenimiento.setFechaRegistro(new Date());
            serviMantenimiento.setRegistrador(1);
            serviMantenimiento.setIdServicio(servicioAdd);
            serviMantenimiento.setIdMantenimiento(mantenimientoRep);
            
            serviMantenimientoFacadeLocal.create(serviMantenimiento);
                        
            //this.cargarRepuestos(mantenimientoRep);
            
            long idMantenimiento = serviMantenimiento.getIdMantenimiento().getIdMantenimiento();            
            this.sergvicioManteList= serviMantenimientoFacadeLocal.findByIdManteni(idMantenimiento);
            
            limpiarDatos();
        } catch (Exception e) {            
            e.printStackTrace();
            System.out.println(":::::::::::::error en la transaccion:::::::::::");
            this.msj = "Error: " + e.getMessage();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    public void eliminarSerMan(ServiMantenimiento reg) throws Exception{
        try {           
           long idMantenimiento = reg.getIdMantenimiento().getIdMantenimiento();
            this.msj = "Registro eliminado correctamente";
            serviMantenimientoFacadeLocal.remove(reg);
            limpiarDatos();            
            this.sergvicioManteList= serviMantenimientoFacadeLocal.findByIdManteni(idMantenimiento);
        } catch (Exception e) {            
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();          
        }
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
}
