/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.ejb;

import com.mycompany.pruebaFA.entity.Rolpersona;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author willy
 */
@Local
public interface RolpersonaFacadeLocal {

    void create(Rolpersona rolpersona);

    void edit(Rolpersona rolpersona);

    void remove(Rolpersona rolpersona);

    Rolpersona find(Object id);

    List<Rolpersona> findAll();

    List<Rolpersona> findRange(int[] range);

    int count();
    
    Rolpersona findByIdRolIdPersona(Long idPersona, int idRol);
    
}
