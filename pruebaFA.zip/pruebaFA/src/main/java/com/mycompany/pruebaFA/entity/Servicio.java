/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.entity;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author willy
 */
@Entity
@Table(name = "servicio")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Servicio.findAll", query = "SELECT s FROM Servicio s"),
    @NamedQuery(name = "Servicio.findByIdServicio", query = "SELECT s FROM Servicio s WHERE s.idServicio = :idServicio"),
    @NamedQuery(name = "Servicio.findByNombre", query = "SELECT s FROM Servicio s WHERE s.nombre = :nombre"),
    @NamedQuery(name = "Servicio.findByPrecioMin", query = "SELECT s FROM Servicio s WHERE s.precioMin = :precioMin"),
    @NamedQuery(name = "Servicio.findByPrecioMax", query = "SELECT s FROM Servicio s WHERE s.precioMax = :precioMax"),
    @NamedQuery(name = "Servicio.findByFechaRegistro", query = "SELECT s FROM Servicio s WHERE s.fechaRegistro = :fechaRegistro"),
    @NamedQuery(name = "Servicio.findByFechaCambio", query = "SELECT s FROM Servicio s WHERE s.fechaCambio = :fechaCambio"),
    @NamedQuery(name = "Servicio.findByRegistrador", query = "SELECT s FROM Servicio s WHERE s.registrador = :registrador")})
public class Servicio implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idServicio")
    private Integer idServicio;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @NotNull
    @Column(name = "precioMin")
    private int precioMin;
    @Basic(optional = false)
    @NotNull
    @Column(name = "precioMax")
    private int precioMax;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaRegistro")
    @Temporal(TemporalType.DATE)
    private Date fechaRegistro;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaCambio")
    @Temporal(TemporalType.DATE)
    private Date fechaCambio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "registrador")
    private long registrador;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idServicio")
    private Collection<ServiMantenimiento> serviMantenimientoCollection;

    public Servicio() {
    }

    public Servicio(Integer idServicio) {
        this.idServicio = idServicio;
    }

    public Servicio(Integer idServicio, String nombre, int precioMin, int precioMax, Date fechaRegistro, Date fechaCambio, long registrador) {
        this.idServicio = idServicio;
        this.nombre = nombre;
        this.precioMin = precioMin;
        this.precioMax = precioMax;
        this.fechaRegistro = fechaRegistro;
        this.fechaCambio = fechaCambio;
        this.registrador = registrador;
    }

    public Integer getIdServicio() {
        return idServicio;
    }

    public void setIdServicio(Integer idServicio) {
        this.idServicio = idServicio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPrecioMin() {
        return precioMin;
    }

    public void setPrecioMin(int precioMin) {
        this.precioMin = precioMin;
    }

    public int getPrecioMax() {
        return precioMax;
    }

    public void setPrecioMax(int precioMax) {
        this.precioMax = precioMax;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public Date getFechaCambio() {
        return fechaCambio;
    }

    public void setFechaCambio(Date fechaCambio) {
        this.fechaCambio = fechaCambio;
    }

    public long getRegistrador() {
        return registrador;
    }

    public void setRegistrador(long registrador) {
        this.registrador = registrador;
    }

    @XmlTransient
    public Collection<ServiMantenimiento> getServiMantenimientoCollection() {
        return serviMantenimientoCollection;
    }

    public void setServiMantenimientoCollection(Collection<ServiMantenimiento> serviMantenimientoCollection) {
        this.serviMantenimientoCollection = serviMantenimientoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idServicio != null ? idServicio.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Servicio)) {
            return false;
        }
        Servicio other = (Servicio) object;
        if ((this.idServicio == null && other.idServicio != null) || (this.idServicio != null && !this.idServicio.equals(other.idServicio))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.mavenproject4.entity.Servicio[ idServicio=" + idServicio + " ]";
    }
    
}
