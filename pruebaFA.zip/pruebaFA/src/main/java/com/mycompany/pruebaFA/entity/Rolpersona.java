/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author willy
 */
@Entity
@Table(name = "rolpersona")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Rolpersona.findAll", query = "SELECT r FROM Rolpersona r"),
    @NamedQuery(name = "Rolpersona.findByIdRolPersona", query = "SELECT r FROM Rolpersona r WHERE r.idRolPersona = :idRolPersona"),
    @NamedQuery(name = "Rolpersona.findByEstado", query = "SELECT r FROM Rolpersona r WHERE r.estado = :estado"),
    @NamedQuery(name = "Rolpersona.findByFechaRegistro", query = "SELECT r FROM Rolpersona r WHERE r.fechaRegistro = :fechaRegistro"),
    @NamedQuery(name = "Rolpersona.findByFechaCambio", query = "SELECT r FROM Rolpersona r WHERE r.fechaCambio = :fechaCambio"),
    @NamedQuery(name = "Rolpersona.findByRegistrador", query = "SELECT r FROM Rolpersona r WHERE r.registrador = :registrador")})
@NamedNativeQuery(name = "Rolpersona.findByIdRolIdPersona", query = "SELECT r.* FROM Rolpersona r WHERE r.idPersona = ? and r.idRol = ?", resultClass = Rolpersona.class)
public class Rolpersona implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idRolPersona")
    private Long idRolPersona;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "estado")
    private String estado;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaRegistro")
    @Temporal(TemporalType.DATE)
    private Date fechaRegistro;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaCambio")
    @Temporal(TemporalType.DATE)
    private Date fechaCambio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "registrador")
    private long registrador;
    @JoinColumn(name = "idPersona", referencedColumnName = "idPersona")
    @ManyToOne(optional = false)
    private Persona idPersona;
    @JoinColumn(name = "idRol", referencedColumnName = "idRol")
    @ManyToOne(optional = false)
    private Rol idRol;

    public Rolpersona() {
    }

    public Rolpersona(Long idRolPersona) {
        this.idRolPersona = idRolPersona;
    }

    public Rolpersona(Long idRolPersona, String estado, Date fechaRegistro, Date fechaCambio, long registrador) {
        this.idRolPersona = idRolPersona;
        this.estado = estado;
        this.fechaRegistro = fechaRegistro;
        this.fechaCambio = fechaCambio;
        this.registrador = registrador;
    }

    public Long getIdRolPersona() {
        return idRolPersona;
    }

    public void setIdRolPersona(Long idRolPersona) {
        this.idRolPersona = idRolPersona;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public Date getFechaCambio() {
        return fechaCambio;
    }

    public void setFechaCambio(Date fechaCambio) {
        this.fechaCambio = fechaCambio;
    }

    public long getRegistrador() {
        return registrador;
    }

    public void setRegistrador(long registrador) {
        this.registrador = registrador;
    }

    public Persona getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(Persona idPersona) {
        this.idPersona = idPersona;
    }

    public Rol getIdRol() {
        return idRol;
    }

    public void setIdRol(Rol idRol) {
        this.idRol = idRol;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idRolPersona != null ? idRolPersona.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Rolpersona)) {
            return false;
        }
        Rolpersona other = (Rolpersona) object;
        if ((this.idRolPersona == null && other.idRolPersona != null) || (this.idRolPersona != null && !this.idRolPersona.equals(other.idRolPersona))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.mavenproject4.entity.Rolpersona[ idRolPersona=" + idRolPersona + " ]";
    }
    
}
