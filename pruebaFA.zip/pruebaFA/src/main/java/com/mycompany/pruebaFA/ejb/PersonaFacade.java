/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.ejb;

import com.mycompany.pruebaFA.entity.Persona;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author willy
 */
@Stateless
public class PersonaFacade extends AbstractFacade<Persona> implements PersonaFacadeLocal {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PersonaFacade() {
        super(Persona.class);
    }
    
    public List<Persona> findAllByIdRol(int idRol) {
        return em.createNamedQuery("Persona.findByIdRol").setParameter("idRol", idRol).getResultList();
    }

    @Override
    public Persona findByIdPersona(Long idPersona) {
        return (Persona)em.createNamedQuery("Persona.findByIdPersona").setParameter("idPersona", idPersona).getSingleResult();
    }
    
    @Override
    public List<Persona> findByMecAsignado() {
        return em.createNamedQuery("Persona.findByMecAsignado").setMaxResults(10).getResultList();
    }
    
    @Override
    public List<Persona> findByMecNoAsignado(int resultados) {
        return em.createNamedQuery("Persona.findByMecNoAsignado").setMaxResults(resultados).getResultList();
    }
    
}
