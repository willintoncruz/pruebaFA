/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.controller;



import com.mycompany.pruebaFA.ejb.TipoDocumentoFacadeLocal;
import com.mycompany.pruebaFA.entity.TipoDocumento;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

/**
 *
 * @author willy
 */
@ManagedBean
@SessionScoped
public class TipoDocumentoBean {
    
    @EJB
    private TipoDocumentoFacadeLocal tipoDocumentoFacade;
    private List<TipoDocumento> tipoDocumentoList;
    private TipoDocumento tipoDocumento;
    private String msj;
    
    
    public List<TipoDocumento> getTipoDocumentoList() {
        this.tipoDocumentoList = tipoDocumentoFacade.findAll();
        return tipoDocumentoList;
    }
 
    public void setTipoDocumentoList(List<TipoDocumento> tipoDocumentoList) {
        this.tipoDocumentoList = tipoDocumentoList;
    }
 
    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }
 
    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }
 
    @PostConstruct
    public void init() {
        this.tipoDocumento = new TipoDocumento();
    }
            
    public void limpiarDatos() {
        this.tipoDocumento = new TipoDocumento();
    }
    
    public void guardar() {
        try {
            
            this.msj = "Registro creado correctamente";
            tipoDocumentoFacade.create(tipoDocumento);
            limpiarDatos();
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    
    public void cargarDatos(TipoDocumento reg) {
        try {
            this.tipoDocumento.setIdTipoDoc(reg.getIdTipoDoc());
            this.tipoDocumento.setNombre(reg.getNombre());
            this.tipoDocumento.setSigla(reg.getSigla());
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
    }
    
    public void actualizar() {
        try {
            this.msj = "Registro actualizado correctamente";
            tipoDocumentoFacade.edit(tipoDocumento);
            
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    public void eliminar(TipoDocumento reg) {
        try {
            this.msj = "Registro eliminado correctamente";
            tipoDocumentoFacade.remove(reg); 
            limpiarDatos();
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
}
