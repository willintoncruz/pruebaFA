/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author willy
 */
@Entity
@Table(name = "serviMantenimiento")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ServiMantenimiento.findAll", query = "SELECT s FROM ServiMantenimiento s"),
    @NamedQuery(name = "ServiMantenimiento.findByIdServiManteni", query = "SELECT s FROM ServiMantenimiento s WHERE s.idServiManteni = :idServiManteni"),
    @NamedQuery(name = "ServiMantenimiento.findByIdManteni", query = "SELECT s FROM ServiMantenimiento s WHERE s.idMantenimiento.idMantenimiento = :idMantenimiento"),
    @NamedQuery(name = "ServiMantenimiento.findByEstado", query = "SELECT s FROM ServiMantenimiento s WHERE s.estado = :estado"),
    @NamedQuery(name = "ServiMantenimiento.findByPrecio", query = "SELECT s FROM ServiMantenimiento s WHERE s.precio = :precio"),
    @NamedQuery(name = "ServiMantenimiento.findByFechaRegistro", query = "SELECT s FROM ServiMantenimiento s WHERE s.fechaRegistro = :fechaRegistro"),
    @NamedQuery(name = "ServiMantenimiento.findByFechaCambio", query = "SELECT s FROM ServiMantenimiento s WHERE s.fechaCambio = :fechaCambio"),
    @NamedQuery(name = "ServiMantenimiento.findByRegistrador", query = "SELECT s FROM ServiMantenimiento s WHERE s.registrador = :registrador")})
public class ServiMantenimiento implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idServiManteni")
    private Long idServiManteni;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "estado")
    private String estado;
    @Basic(optional = false)
    @NotNull
    @Column(name = "precio")
    private int precio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaRegistro")
    @Temporal(TemporalType.DATE)
    private Date fechaRegistro;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaCambio")
    @Temporal(TemporalType.DATE)
    private Date fechaCambio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "registrador")
    private long registrador;
    @JoinColumn(name = "idMantenimiento", referencedColumnName = "idMantenimiento")
    @ManyToOne(optional = false)
    private Mantenimiento idMantenimiento;
    @JoinColumn(name = "idServicio", referencedColumnName = "idServicio")
    @ManyToOne(optional = false)
    private Servicio idServicio;

    public ServiMantenimiento() {
    }

    public ServiMantenimiento(Long idServiManteni) {
        this.idServiManteni = idServiManteni;
    }

    public ServiMantenimiento(Long idServiManteni, String estado, int precio, Date fechaRegistro, Date fechaCambio, long registrador) {
        this.idServiManteni = idServiManteni;
        this.estado = estado;
        this.precio = precio;
        this.fechaRegistro = fechaRegistro;
        this.fechaCambio = fechaCambio;
        this.registrador = registrador;
    }

    public Long getIdServiManteni() {
        return idServiManteni;
    }

    public void setIdServiManteni(Long idServiManteni) {
        this.idServiManteni = idServiManteni;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public Date getFechaCambio() {
        return fechaCambio;
    }

    public void setFechaCambio(Date fechaCambio) {
        this.fechaCambio = fechaCambio;
    }

    public long getRegistrador() {
        return registrador;
    }

    public void setRegistrador(long registrador) {
        this.registrador = registrador;
    }

    public Mantenimiento getIdMantenimiento() {
        return idMantenimiento;
    }

    public void setIdMantenimiento(Mantenimiento idMantenimiento) {
        this.idMantenimiento = idMantenimiento;
    }

    public Servicio getIdServicio() {
        return idServicio;
    }

    public void setIdServicio(Servicio idServicio) {
        this.idServicio = idServicio;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idServiManteni != null ? idServiManteni.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ServiMantenimiento)) {
            return false;
        }
        ServiMantenimiento other = (ServiMantenimiento) object;
        if ((this.idServiManteni == null && other.idServiManteni != null) || (this.idServiManteni != null && !this.idServiManteni.equals(other.idServiManteni))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.mavenproject4.entity.ServiMantenimiento[ idServiManteni=" + idServiManteni + " ]";
    }
    
}
