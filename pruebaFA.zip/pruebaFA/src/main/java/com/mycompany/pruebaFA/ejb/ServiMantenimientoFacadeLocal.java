/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.ejb;

import com.mycompany.pruebaFA.entity.ServiMantenimiento;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author willy
 */
@Local
public interface ServiMantenimientoFacadeLocal {

    void create(ServiMantenimiento serviMantenimiento);

    void edit(ServiMantenimiento serviMantenimiento);

    void remove(ServiMantenimiento serviMantenimiento);

    ServiMantenimiento find(Object id);

    List<ServiMantenimiento> findAll();

    List<ServiMantenimiento> findRange(int[] range);

    int count();
    
    List<ServiMantenimiento> findByIdManteni(Long idMantenimiento);
    
}
