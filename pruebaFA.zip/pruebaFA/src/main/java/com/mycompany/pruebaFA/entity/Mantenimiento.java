/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.entity;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author willy
 */
@Entity
@Table(name = "mantenimiento")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Mantenimiento.findAll", query = "SELECT m FROM Mantenimiento m"),
    @NamedQuery(name = "Mantenimiento.findByIdMantenimiento", query = "SELECT m FROM Mantenimiento m WHERE m.idMantenimiento = :idMantenimiento"),
    @NamedQuery(name = "Mantenimiento.findByPresupuesto", query = "SELECT m FROM Mantenimiento m WHERE m.presupuesto = :presupuesto"),
    @NamedQuery(name = "Mantenimiento.findByTiempo", query = "SELECT m FROM Mantenimiento m WHERE m.tiempo = :tiempo"),
    @NamedQuery(name = "Mantenimiento.findByFechaRegistro", query = "SELECT m FROM Mantenimiento m WHERE m.fechaRegistro = :fechaRegistro"),
    @NamedQuery(name = "Mantenimiento.findByFechaCambio", query = "SELECT m FROM Mantenimiento m WHERE m.fechaCambio = :fechaCambio"),
    @NamedQuery(name = "Mantenimiento.findByRegistrador", query = "SELECT m FROM Mantenimiento m WHERE m.registrador = :registrador")})
public class Mantenimiento implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idMantenimiento")
    private Long idMantenimiento;
    @Basic(optional = false)
    @NotNull
    @Column(name = "presupuesto")
    private int presupuesto;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "tiempo")
    private String tiempo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaRegistro")
    @Temporal(TemporalType.DATE)
    private Date fechaRegistro;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaCambio")
    @Temporal(TemporalType.DATE)
    private Date fechaCambio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "registrador")
    private long registrador;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idMantenimiento")
    private Collection<RepuestoManteni> repuestoManteniCollection;
    
    @JoinColumn(name = "idMecanico", referencedColumnName = "idPersona")
    @ManyToOne(optional = false)
    private Persona idMecanico;
    
    @JoinColumn(name = "idVehiculo", referencedColumnName = "idVehiculo")
    @ManyToOne(optional = false)
    private Vehiculo idVehiculo;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idMantenimiento")
    private Collection<ServiMantenimiento> serviMantenimientoCollection;

    public Mantenimiento() {
    }

    public Mantenimiento(Long idMantenimiento) {
        this.idMantenimiento = idMantenimiento;
    }

    public Mantenimiento(Long idMantenimiento, int presupuesto, String tiempo, Date fechaRegistro, Date fechaCambio, long registrador) {
        this.idMantenimiento = idMantenimiento;
        this.presupuesto = presupuesto;
        this.tiempo = tiempo;
        this.fechaRegistro = fechaRegistro;
        this.fechaCambio = fechaCambio;
        this.registrador = registrador;
    }

    public Long getIdMantenimiento() {
        return idMantenimiento;
    }

    public void setIdMantenimiento(Long idMantenimiento) {
        this.idMantenimiento = idMantenimiento;
    }

    public int getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(int presupuesto) {
        this.presupuesto = presupuesto;
    }

    public String getTiempo() {
        return tiempo;
    }

    public void setTiempo(String tiempo) {
        this.tiempo = tiempo;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public Date getFechaCambio() {
        return fechaCambio;
    }

    public void setFechaCambio(Date fechaCambio) {
        this.fechaCambio = fechaCambio;
    }

    public long getRegistrador() {
        return registrador;
    }

    public void setRegistrador(long registrador) {
        this.registrador = registrador;
    }

    @XmlTransient
    public Collection<RepuestoManteni> getRepuestoManteniCollection() {
        return repuestoManteniCollection;
    }

    public void setRepuestoManteniCollection(Collection<RepuestoManteni> repuestoManteniCollection) {
        this.repuestoManteniCollection = repuestoManteniCollection;
    }

    public Persona getIdMecanico() {
        return idMecanico;
    }

    public void setIdMecanico(Persona idMecanico) {
        this.idMecanico = idMecanico;
    }

    public Vehiculo getIdVehiculo() {
        return idVehiculo;
    }

    public void setIdVehiculo(Vehiculo idVehiculo) {
        this.idVehiculo = idVehiculo;
    }

    @XmlTransient
    public Collection<ServiMantenimiento> getServiMantenimientoCollection() {
        return serviMantenimientoCollection;
    }

    public void setServiMantenimientoCollection(Collection<ServiMantenimiento> serviMantenimientoCollection) {
        this.serviMantenimientoCollection = serviMantenimientoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idMantenimiento != null ? idMantenimiento.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mantenimiento)) {
            return false;
        }
        Mantenimiento other = (Mantenimiento) object;
        if ((this.idMantenimiento == null && other.idMantenimiento != null) || (this.idMantenimiento != null && !this.idMantenimiento.equals(other.idMantenimiento))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.mavenproject4.entity.Mantenimiento[ idMantenimiento=" + idMantenimiento + " ]";
    }
    
}
