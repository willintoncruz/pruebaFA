/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.controller;



import com.mycompany.pruebaFA.ejb.ServicioFacadeLocal;
import com.mycompany.pruebaFA.entity.Servicio;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

/**
 *
 * @author willy
 */
@ManagedBean
@SessionScoped
public class ServicioBean {

    
     @EJB
    private ServicioFacadeLocal servicioFacadeLocal;
    private List<Servicio> servicioList;
    private Servicio servicio;
    private String msj;
    
    
    
    /**
     * @return the servicioList
     */
    public List<Servicio> getServicioList() {
        this.servicioList = servicioFacadeLocal.findAll();
        return servicioList;
    }

    /**
     * @param servicioList the servicioList to set
     */
    public void setServicioList(List<Servicio> servicioList) {
        this.servicioList = servicioList;
    }
    
   
    
    
 
    public Servicio getServicio() {
        return servicio;
    }
 
    public void setServicio(Servicio servicio) {
        this.servicio = servicio;
    }
 
    @PostConstruct
    public void init() {
        this.servicio = new Servicio();
    }
            
    public void limpiarDatos() {
        this.servicio = new Servicio();
    }
    
    public void guardar() {
        try {
            
            this.msj = "Registro creado correctamente";
            servicio.setFechaCambio(new Date());
            servicio.setFechaRegistro(new Date());
            servicio.setRegistrador(1);
            System.out.println("esta en el registar::::::::");
            servicioFacadeLocal.create(servicio);
            limpiarDatos();
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    
    public void cargarDatos(Servicio reg) {
        try {
            this.servicio.setIdServicio(reg.getIdServicio());
            this.servicio.setNombre(reg.getNombre());
            this.servicio.setPrecioMin(reg.getPrecioMin());
            this.servicio.setPrecioMax(reg.getPrecioMax());
            this.servicio.setFechaCambio(reg.getFechaCambio());
            this.servicio.setFechaRegistro(reg.getFechaRegistro());
            this.servicio.setRegistrador(reg.getRegistrador());
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
    }
    
    public void actualizar() {
        try {
            this.msj = "Registro actualizado correctamente";
            servicio.setFechaCambio(new Date());
            servicio.setRegistrador(1);
            servicioFacadeLocal.edit(servicio);
            
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    public void eliminar(Servicio reg) {
        try {
            this.msj = "Registro eliminado correctamente";
            servicioFacadeLocal.remove(reg); 
            limpiarDatos();
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
}
