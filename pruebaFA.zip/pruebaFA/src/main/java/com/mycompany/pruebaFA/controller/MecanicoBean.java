/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.controller;



import com.mycompany.pruebaFA.ejb.PersonaFacadeLocal;
import com.mycompany.pruebaFA.ejb.RolFacadeLocal;
import com.mycompany.pruebaFA.ejb.RolpersonaFacadeLocal;
import com.mycompany.pruebaFA.entity.Persona;
import com.mycompany.pruebaFA.entity.Rol;
import com.mycompany.pruebaFA.entity.Rolpersona;
import com.mycompany.pruebaFA.entity.TipoDocumento;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.transaction.UserTransaction;
import javax.annotation.Resource;
import javax.transaction.Status;

/**
 *
 * @author willy
 */
@ManagedBean
@SessionScoped
@TransactionManagement(TransactionManagementType.BEAN)
public class MecanicoBean {
    
    @Resource
   private UserTransaction userTransaction;
    
     @EJB
    private PersonaFacadeLocal personaFacadeLocal;
     
     @EJB
    private RolFacadeLocal rolFacadeLocal;
     
     @EJB
    private RolpersonaFacadeLocal rolpersonaFacadeLocal;
     
    private List<Persona> personaList;
    private Persona persona;
    private TipoDocumento tipoDocumento;
    private Rolpersona rolpersona;
    private Rol rol;
    private String msj;
    
    /**
     * @return the tipoDocumento
     */
    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }

    /**
     * @param tipoDocumento the tipoDocumento to set
     */
    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }
    
   
    
    
    public List<Persona> getPersonaList() {
        this.personaList = personaFacadeLocal.findAllByIdRol(1);
        
        this.rol = rolFacadeLocal.findByName("MECANICO");
        return personaList;
    }
 
    public void setPersonaList(List<Persona> respuestoList) {
        this.personaList = personaList;
    }
 
    public Persona getPersona() {
        return persona;
    }
 
    public void setPersona(Persona persona) {
        this.persona = persona;
    }
 
    @PostConstruct
    public void init() {
        this.persona = new Persona();
        this.tipoDocumento = new TipoDocumento();
        this.rolpersona = new Rolpersona();
    }
            
    public void limpiarDatos() {
        this.persona = new Persona();
        this.tipoDocumento = new TipoDocumento();
    }
    
  
    public void guardar() throws Exception{
        try {
            
            userTransaction.begin();
            
            this.msj = "Registro creado correctamente";
            System.out.println("tipoDocumento:::::::" + this.tipoDocumento.getIdTipoDoc());
            persona.setIdTipoDoc(this.tipoDocumento);
            persona.setFechaCambio(new Date());
            persona.setFechaRegistro(new Date());
            persona.setRegistrador(1);
            personaFacadeLocal.create(persona);
            
            //this.rol.setIdRol(77);
            rolpersona= new Rolpersona();
            rolpersona.setIdRol(this.rol);
            rolpersona.setEstado("L");
            rolpersona.setFechaCambio(new Date());
            rolpersona.setFechaRegistro(new Date());
            rolpersona.setRegistrador(1);
            rolpersona.setIdPersona(persona);
            
            rolpersonaFacadeLocal.create(rolpersona);
            
            userTransaction.commit();
            
            limpiarDatos();
        } catch (Exception e) {
            
            e.printStackTrace();
            System.out.println(":::::::::::::error en la transaccion:::::::::::");
            //this.msj = "Error: " + e.getMessage();
            this.msj = "Error: error en la transaccion";
            //userTransaction.rollback();
            if (userTransaction.getStatus() == Status.STATUS_ACTIVE)
                    userTransaction.rollback();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    
    public void cargarDatos(Persona reg) {
        try {
            this.persona.setIdPersona(reg.getIdPersona());
            this.persona.setNombre1(reg.getNombre1());
            this.persona.setNombre2(reg.getNombre2());
            this.persona.setApellido1(reg.getApellido1());
            this.persona.setApellido2(reg.getApellido2());
            this.persona.setIdTipoDoc(reg.getIdTipoDoc());
            this.persona.setEmail(reg.getEmail());
            this.persona.setDireccion(reg.getDireccion());
            this.persona.setTelefono(reg.getTelefono());
            this.persona.setNumeroDoc(reg.getNumeroDoc());
            
            this.tipoDocumento.setIdTipoDoc(this.persona.getIdTipoDoc().getIdTipoDoc());
            System.out.println("this.tipoDocumento.getIdTipoDoc():::::::::" + this.tipoDocumento.getIdTipoDoc());
            
            this.persona.setFechaCambio(reg.getFechaCambio());
            this.persona.setFechaRegistro(reg.getFechaRegistro());            
            this.persona.setRegistrador(reg.getRegistrador());
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
    }
    
    public void actualizar() {
        try {
            this.msj = "Registro actualizado correctamente";
            persona.setFechaCambio(new Date());
            persona.setRegistrador(1);
            persona.setIdTipoDoc(this.tipoDocumento);
            personaFacadeLocal.edit(persona);
            
            //this.rol.setIdRol(77);
            rolpersona= new Rolpersona();
            rolpersona.setIdRol(this.rol);
            rolpersona.setEstado("L");
            rolpersona.setFechaCambio(new Date());
            rolpersona.setRegistrador(1);
            rolpersona.setIdPersona(persona);
            
            rolpersonaFacadeLocal.edit(rolpersona);
            
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    public void eliminar(Persona reg) {
        try {
            this.msj = "Registro eliminado correctamente";
            personaFacadeLocal.remove(reg); 
            limpiarDatos();
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
}
