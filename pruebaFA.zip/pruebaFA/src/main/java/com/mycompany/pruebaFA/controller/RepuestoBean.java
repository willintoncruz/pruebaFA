/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.controller;



import com.mycompany.pruebaFA.ejb.RepuestoFacadeLocal;
import com.mycompany.pruebaFA.entity.Repuesto;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

/**
 *
 * @author willy
 */
@ManagedBean
@SessionScoped
public class RepuestoBean {
    
    @EJB
    private RepuestoFacadeLocal repuestoFacadeLocal;
    private List<Repuesto> respuestoList;
    private Repuesto repuesto;
    private String msj;
    
    
    public List<Repuesto> getRepuestoList() {
        this.respuestoList = repuestoFacadeLocal.findAll();
        return respuestoList;
    }
 
    public void setRepuestoList(List<Repuesto> respuestoList) {
        this.respuestoList = respuestoList;
    }
 
    public Repuesto getRepuesto() {
        return repuesto;
    }
 
    public void setRepuesto(Repuesto repuesto) {
        this.repuesto = repuesto;
    }
 
    @PostConstruct
    public void init() {
        this.repuesto = new Repuesto();
    }
            
    public void limpiarDatos() {
        this.repuesto = new Repuesto();
    }
    
    public void guardar() {
        try {
            
            this.msj = "Registro creado correctamente";
            repuesto.setFechaCambio(new Date());
            repuesto.setFechaRegistro(new Date());
            repuesto.setRegistrador(1);
            repuestoFacadeLocal.create(repuesto);
            limpiarDatos();
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    
    public void cargarDatos(Repuesto reg) {
        try {
            this.repuesto.setIdRepuesto(reg.getIdRepuesto());
            this.repuesto.setNombre(reg.getNombre());
            this.repuesto.setMarca(reg.getMarca());
            this.repuesto.setPrecio(reg.getPrecio());
            this.repuesto.setFechaCambio(reg.getFechaCambio());
            this.repuesto.setFechaRegistro(reg.getFechaRegistro());
            this.repuesto.setRegistrador(reg.getRegistrador());
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
    }
    
    public void actualizar() {
        try {
            this.msj = "Registro actualizado correctamente";
            repuesto.setFechaCambio(new Date());
            repuesto.setRegistrador(1);
            repuestoFacadeLocal.edit(repuesto);
            
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
 
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
    
    public void eliminar(Repuesto reg) {
        try {
            this.msj = "Registro eliminado correctamente";
            repuestoFacadeLocal.remove(reg); 
            limpiarDatos();
        } catch (Exception e) {
            e.printStackTrace();
            this.msj = "Error: " + e.getMessage();
        }
        FacesMessage mensaje = new FacesMessage(this.msj);
        FacesContext.getCurrentInstance().addMessage(msj, mensaje);
    }
}
