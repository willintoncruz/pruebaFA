/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.ejb;

import com.mycompany.pruebaFA.entity.Repuesto;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author willy
 */
@Stateless
public class RepuestoFacade extends AbstractFacade<Repuesto> implements RepuestoFacadeLocal {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public RepuestoFacade() {
        super(Repuesto.class);
    }
    
     @Override
    public List<Repuesto> findByIdMantenimiento(Long idMantenimiento) {
        return em.createNamedQuery("Repuesto.findByIdMantenimiento").setParameter(1, idMantenimiento).getResultList();
    }
    
}
