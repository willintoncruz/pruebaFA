/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.controller;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;

/**
 *
 * @author willy
 */
@ManagedBean
@SessionScoped
public class NavegadorBean {
    
    private String navigationUrl = "blank";
    
    /**
     * @return the navigationUrl
     */
    public String getNavigationUrl() {
        return navigationUrl;
    }

    /**
     * @param navigationUrl the navigationUrl to set
     */
    public void setNavigationUrl(String navigationUrl) {
        this.navigationUrl = navigationUrl;
    }
    
    public void navegar(ActionEvent event){
        try{
        String pagina = (String) event.getComponent().getAttributes().get("rutaPagina");
        this.setNavigationUrl(pagina);
            System.out.println("esta en navegar::" + this.getNavigationUrl());
        } catch (Exception e) {
            System.out.print("Se ha producido un error :" + e);
            e.printStackTrace();
        }
    }
    
    public void navegarMenu(ActionEvent event){
        try{
        String pagina = (String) event.getComponent().getAttributes().get("rutaPagina");
        this.setNavigationUrl(pagina);
            System.out.println("esta en navegar::" + this.getNavigationUrl());
        } catch (Exception e) {
            System.out.print("Se ha producido un error :" + e);
            e.printStackTrace();
        }
    }
    
    public String irGestionDocumentoAction() {
		return "ir_gestion_tipodoc";
	}
    
    public String irGestionRespuestoAction() {
		return "ir_gestion_repuesto";
	}
    
}
