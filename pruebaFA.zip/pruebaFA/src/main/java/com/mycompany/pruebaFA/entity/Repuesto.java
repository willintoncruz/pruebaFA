/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.pruebaFA.entity;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author willy
 */
@Entity
@Table(name = "repuesto")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Repuesto.findAll", query = "SELECT r FROM Repuesto r"),
    @NamedQuery(name = "Repuesto.findByIdRepuesto", query = "SELECT r FROM Repuesto r WHERE r.idRepuesto = :idRepuesto"),
    @NamedQuery(name = "Repuesto.findByIdMante", query = "SELECT r FROM Repuesto r, RepuestoManteni rm WHERE r.idRepuesto = rm.idRepuesto and  rm.idMantenimiento = :idMantenimiento"),
    @NamedQuery(name = "Repuesto.findByNombre", query = "SELECT r FROM Repuesto r WHERE r.nombre = :nombre"),
    @NamedQuery(name = "Repuesto.findByMarca", query = "SELECT r FROM Repuesto r WHERE r.marca = :marca"),
    @NamedQuery(name = "Repuesto.findByPrecio", query = "SELECT r FROM Repuesto r WHERE r.precio = :precio"),
    @NamedQuery(name = "Repuesto.findByFechaRegistro", query = "SELECT r FROM Repuesto r WHERE r.fechaRegistro = :fechaRegistro"),
    @NamedQuery(name = "Repuesto.findByFechaCambio", query = "SELECT r FROM Repuesto r WHERE r.fechaCambio = :fechaCambio"),
    @NamedQuery(name = "Repuesto.findByRegistrador", query = "SELECT r FROM Repuesto r WHERE r.registrador = :registrador")})
@NamedNativeQuery(name = "Repuesto.findByIdMantenimiento", query = "SELECT rm.idRepuestoManteni idRepuestoManteni, r.fechaCambio, r.fechaRegistro, r.idRepuesto, r.marca, r.nombre, r.precio, r.registrador FROM repuesto r, repuestoManteni rm WHERE r.idRepuesto = rm.idRepuesto and rm.idMantenimiento = ?", resultSetMapping = "PostWithCommentCountMapping")

@SqlResultSetMapping(
    name = "PostWithCommentCountMapping",
    entities = @EntityResult(
        entityClass = Repuesto.class,
        fields = {
            @FieldResult(name = "idRepuestoManteni", column = "idRepuestoManteni)"),
        }
    )
)
public class Repuesto implements Serializable {

    /**
     * @return the repuestoManteni
     */
    public RepuestoManteni getRepuestoManteni() {
        return repuestoManteni;
    }

    /**
     * @param repuestoManteni the repuestoManteni to set
     */
    public void setRepuestoManteni(RepuestoManteni repuestoManteni) {
        this.repuestoManteni = repuestoManteni;
    }

    /**
     * @return the idRepuestoManteni
     */
    public long getIdRepuestoManteni() {
        return idRepuestoManteni;
    }

    /**
     * @param idRepuestoManteni the idRepuestoManteni to set
     */
    public void setIdRepuestoManteni(long idRepuestoManteni) {
        this.idRepuestoManteni = idRepuestoManteni;
    }

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idRepuesto")
    private Long idRepuesto;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "marca")
    private String marca;
    @Basic(optional = false)
    @NotNull
    @Column(name = "precio")
    private int precio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaRegistro")
    @Temporal(TemporalType.DATE)
    private Date fechaRegistro;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaCambio")
    @Temporal(TemporalType.DATE)
    private Date fechaCambio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "registrador")
    private long registrador;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idRepuesto")
    private Collection<RepuestoManteni> repuestoManteniCollection;
    
    @Transient
     private long idRepuestoManteni;
    
    @Transient
     private RepuestoManteni repuestoManteni;
     
    public Repuesto() {
    }

    public Repuesto(Long idRepuesto) {
        this.idRepuesto = idRepuesto;
    }

    public Repuesto(Long idRepuesto, String nombre, String marca, int precio, Date fechaRegistro, Date fechaCambio, long registrador, long idRepuestoManteni) {
        this.idRepuesto = idRepuesto;
        this.nombre = nombre;
        this.marca = marca;
        this.precio = precio;
        this.fechaRegistro = fechaRegistro;
        this.fechaCambio = fechaCambio;
        this.registrador = registrador;
        this.idRepuestoManteni = idRepuestoManteni;
    }

    public Long getIdRepuesto() {
        return idRepuesto;
    }

    public void setIdRepuesto(Long idRepuesto) {
        this.idRepuesto = idRepuesto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public Date getFechaCambio() {
        return fechaCambio;
    }

    public void setFechaCambio(Date fechaCambio) {
        this.fechaCambio = fechaCambio;
    }

    public long getRegistrador() {
        return registrador;
    }

    public void setRegistrador(long registrador) {
        this.registrador = registrador;
    }

    @XmlTransient
    public Collection<RepuestoManteni> getRepuestoManteniCollection() {
        return repuestoManteniCollection;
    }

    public void setRepuestoManteniCollection(Collection<RepuestoManteni> repuestoManteniCollection) {
        this.repuestoManteniCollection = repuestoManteniCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idRepuesto != null ? idRepuesto.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Repuesto)) {
            return false;
        }
        Repuesto other = (Repuesto) object;
        if ((this.idRepuesto == null && other.idRepuesto != null) || (this.idRepuesto != null && !this.idRepuesto.equals(other.idRepuesto))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.mavenproject4.entity.Repuesto[ idRepuesto=" + idRepuesto + " - idRepuestoManteni: " + idRepuestoManteni +" - nombre: " + nombre +" ]";
    }
    
    
    
}
